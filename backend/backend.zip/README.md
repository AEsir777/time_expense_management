﻿# time_expense_management
- django implements REST API: Create Retrive Update Delete
  ![image](https://user-images.githubusercontent.com/77596290/201259800-e459b7c3-2e3b-4cda-89aa-7b00d71ab147.png)

- react with bootstrap framework: edit the list
  ![image](https://user-images.githubusercontent.com/77596290/201795517-0fb73b39-afc9-497f-aea9-fa3f7b395311.png)
